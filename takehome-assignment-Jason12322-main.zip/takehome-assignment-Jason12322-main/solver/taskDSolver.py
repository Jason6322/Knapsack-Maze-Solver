# -------------------------------------------------------------------
# PLEASE UPDATE THIS FILE.
# Greedy maze solver for all entrance, exit pairs
#
# __author__ = <student name here>
# __copyright__ = 'Copyright 2025, RMIT University'
# -------------------------------------------------------------------


from maze.util import Coordinates
from maze.maze import Maze

from knapsack.knapsack import Knapsack
from itertools import permutations

from typing import List, Dict, Optional


class TaskDSolver:
    def __init__(self, knapsack:Knapsack):
        self.m_solverPath: List[Coordinates] = []
        self.m_cellsExplored = 0 # count of UNIQUE cells visited. i.e. final count should equal len(set(self.m_solverPath))
        self.m_entranceUsed = None
        self.m_exitUsed = None
        self.m_knapsack = knapsack
        self.m_value = 0
        self.m_reward = float('-inf') # initial reward should be terrible

        # you may which to add more parameters here, such as probabilities, etc
        # you may update these parameters using the Maze object in SolveMaze

    def reward(self):
        return self.m_knapsack.optimalValue - self.m_cellsExplored
    def checkPathLegal(self, maze:Maze, entrance:Coordinates, exit:Coordinates):
        """
        Checks if the generated path is legal. Throws an error if not.
        Also checks that the path starts at the entrance and ends at the exit.
        """
        if not self.m_solverPath:
            raise ValueError("Illegal path: Path is empty.")

        # Check start and end positions
        if self.m_solverPath[0] != entrance:
            raise ValueError(
                f"Illegal path: Path does not start at entrance ({entrance.getRow()}, {entrance.getCol()})."
            )
        if self.m_solverPath[-1] != exit:
            raise ValueError(
                f"Illegal path: Path does not end at exit ({exit.getRow()}, {exit.getCol()})."
            )

        # LEGAL PATH CHECK
        for i in range(1, len(self.m_solverPath)):
            prev = self.m_solverPath[i - 1]
            curr = self.m_solverPath[i]
            # Check adjacency
            if curr not in maze.neighbours(prev):
                raise ValueError(
                    f"Illegal path: ({prev.getRow()}, {prev.getCol()}) and ({curr.getRow()}, {curr.getCol()}) are not adjacent."
                )
            # Check for wall
            if maze.hasWall(prev, curr):
                raise ValueError(
                    f"Illegal path: Wall between ({prev.getRow()}, {prev.getCol()}) and ({curr.getRow()}, {curr.getCol()})."
                )

        print("Path is legal.")

    
    def solveMaze(self, maze: Maze, entrance: Coordinates, exit: Coordinates):
        """
        Solution for Task D goes here.

        Be sure to increase self.m_cellsExplored whenever you visit a NEW cell
        Be sure to increase the knapsack_value whenever you find an item and put it in your knapsack.
        You may use the maze object to check if a cell you visit has an item
        maze.m_itemParams can be used to calculate things like predicted reward, etc. But you can only use
        maze.m_items to check if your current cell contains an item (and if so, what is its weight and value)

        Code in this function will be rigorously tested. An honest but bad solution will still gain quite a few marks.
        A cheated solution will gain 0 marks for all of Task D.
        Args:
        maze: maze object
        entrance: initial entrance coord
        exit: exit coord

        Returns: Nothing, but updates variables
        """


        
        from collections import deque
        """
        To maximize reward could make an array with treasure and their weight and value then at the end when at exit use knapsack solver to find best values unable to due time constraints
        """
        self.m_solverPath = []
        self.m_cellsExplored = 0
        self.m_knapsack.optimalCells = []
        self.m_knapsack.optimalValue = 0
        self.m_knapsack.optimalWeight = 0
        self.m_entranceUsed = entrance
        self.m_exitUsed = exit

        visitedCells = set()
        fullPath = [entrance]
        current = entrance

        # BFS explore the maze
        queue = deque()
        queue.append((current, [current]))
        while queue:
            position, path = queue.popleft()
            if position not in visitedCells:
                visitedCells.add(position)
                fullPath = path  # Most recent path to current cell

                # Add neighbors for BFS
                for neighbor in maze.neighbours(position):
                    if neighbor not in visitedCells and not maze.hasWall(position, neighbor):
                        queue.append((neighbor, path + [neighbor]))

        # End at exit by getting shortest path from last cell to exit
        if fullPath[-1] != exit:
            # BFS from last cell to exit
            prev = {}
            q_exit = deque()
            q_exit.append(fullPath[-1])
            prev[fullPath[-1]] = None
            found = False
            while q_exit and not found:
                node = q_exit.popleft()
                for neighbor in maze.neighbours(node):
                    if not maze.hasWall(node, neighbor) and neighbor not in prev:
                        prev[neighbor] = node
                        if neighbor == exit:
                            found = True
                            break
                        q_exit.append(neighbor)
            # Reconstruct path and extend
            out_path = []
            node = exit
            while node is not None:
                out_path.append(node)
                node = prev[node]
            out_path = list(reversed(out_path))
            fullPath.extend(out_path[1:])

        self.m_solverPath = fullPath
        self.m_cellsExplored = len(set(self.m_solverPath))

        # Check items along the path in order
        for position in self.m_solverPath:
            pos_tuple = (position.getRow(), position.getCol())
            if pos_tuple in maze.m_items and pos_tuple not in self.m_knapsack.optimalCells:
                weight, value = maze.m_items[pos_tuple]
                if self.m_knapsack.optimalWeight + weight <= self.m_knapsack.capacity:
                    self.m_knapsack.optimalCells.append(pos_tuple)
                    self.m_knapsack.optimalWeight += weight
                    self.m_knapsack.optimalValue += value

        self.m_reward = self.reward()
        self.checkPathLegal(maze, entrance, exit)

        print("Picked up treasures:", self.m_knapsack.optimalCells)
        print("Total value:", self.m_knapsack.optimalValue)
        print("Total weight:", self.m_knapsack.optimalWeight)