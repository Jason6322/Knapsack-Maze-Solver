# -------------------------------------------------
# File for Tasks A and B
# Class for knapsack
# PLEASE UPDATE THIS FILE
#
# __author__ = 'Edward Small'
# __copyright__ = 'Copyright 2025, RMIT University'
# -------------------------------------------------

import csv
import time
from maze.maze import Maze


class Knapsack:
    """
    Base class for the knapsack.
    """

    def __init__(self, capacity: int, knapsackSolver: str):
        """
        Constructor.

        @param capacity: the maximum weight the knapsack can hold
        @param knapsackSolver: the method we wish to use to find optimal knapsack items (recur or dynamic)
        """
        # initialise variables
        self.capacity = capacity
        self.optimalValue = 0
        self.optimalWeight = 0
        self.optimalCells = []
        self.knapsackSolver = knapsackSolver

    def solveKnapsack(self, maze: Maze, filename: str):
        """
        Calls the method to calculate the optimal knapsack solution
        @param maze: The maze we are considering
        """
        map = []
        # Sort by row (i) first, then column (j)
        sorted_items = sorted(maze.m_items.items(), key=lambda item: (item[0][0], item[0][1]))

        for cell, (weight, value) in sorted_items:
            map.append([cell, weight, value])

        if self.knapsackSolver == "recur":
            self.optimalCells, self.optimalWeight, self.optimalValue = self.recursiveKnapsack(map,
                                                                                              self.capacity,
                                                                                              len(map),
                                                                                              filename)
        elif self.knapsackSolver == "dynamic":
            self.optimalCells, self.optimalWeight, self.optimalValue = self.dynamicKnapsack(map,
                                                                                            self.capacity,
                                                                                            len(map),
                                                                                            filename)

        else:
            raise Exception("Incorrect Knapsack Solver Used.")

    def recursiveKnapsack(self, items: list, capacity: int, num_items: int, filename: str = None,
                          stats={'count': 0, 'logged': False}):
        """
        Recursive 0/1 Knapsack that logs how many times it's been called
        when the base case is first hit.

        @param items: list of (name, weight, value)
        @param capacity: current remaining knapsack capacity
        @param num_items: number of items still being considered
        @param filename: where to save call count on first base case (used for testing)
        @param stats: dict tracking call count and log status (used for testing)
        """
        # Increment call count on every call - feed back into the function on each call for testing
        stats['count'] += 1

        # Base case
        if capacity == 0 or num_items == 0:
            if not stats['logged'] and filename:
                with open(filename+'.txt', "w") as f:
                    f.write(str(stats['count']))
                stats['logged'] = True  # Make sure we only log once
            return [], 0, 0
        
        # Get current item
        location, weight, value = items[num_items - 1]
        
        # If weight is greater than capacity
        if weight > capacity:
            return self.recursiveKnapsack(items, capacity, num_items - 1, filename, stats)
        
        # Include current item
        include_location, included_weight, included_value = self.recursiveKnapsack(items, capacity - weight, num_items - 1, filename, stats)

        # Exclude current item
        excluded_location, excluded_weight, excluded_value = self.recursiveKnapsack(items, capacity, num_items - 1, filename, stats)

        if included_value + value > excluded_value:
            optimal_location = include_location + [location]
            optimal_weight = included_weight + weight
            optimal_value = included_value + value
        else:
            optimal_location = excluded_location
            optimal_weight = excluded_weight
            optimal_value = excluded_value
        return optimal_location, optimal_weight, optimal_value
    def dynamicKnapsack(self, items: list, capacity: int, num_items: int, filename: str):
        """
        Dynamic 0/1 Knapsack that saves the dynamic programming table as a csv.

        @param items: list of (name, weight, value)
        @param capacity: current remaining knapsack capacity
        @param num_items: number of items still being considered
        @param filename: save name for csv of table (used for testing)
        """
        start = time.perf_counter()
        # Initialize DP table with None
        dp = [[None] * (capacity + 1) for _ in range(num_items + 1)]
        # first row is all 0s
        dp[0] = [0] * (capacity + 1)

        def F(i, j):
            # Base case: no items or no capacity
            if i == 0 or j == 0:
                dp[i][j] = 0
                return 0
            # Memoization check: Return result if available
            if dp[i][j] is not None:
                return dp[i][j]
            # Current item details
            cell, weight, value = items[i - 1]
            # If weight is more than carrying capacity, exclude it
            if weight > j:
                dp[i][j] = F(i - 1, j)
            else:
                # Choose maximum of including or excluding the item
                dp[i][j] = max(F(i - 1, j), F(i - 1, j - weight) + value)
            return dp[i][j]
        
        # Compute maximum value
        max_value = F(num_items, capacity)


        # Backtrack to find selected items
        selected_items = []
        current_cap = capacity
        selected_weight = 0
        # Iterate backwards through all items
        for i in range(num_items, 0, -1):
            # If item included add
            if current_cap > 0 and dp[i][current_cap] != dp[i-1][current_cap]:
                selected_items.append(items[i-1][0])  # Add item location
                selected_weight += items[i-1][1]
                current_cap -= items[i-1][1]
        
        selected_items.reverse()  # To maintain original order

        # === Save DP Table to CSV ===
        self.saveCSV(dp, items, capacity, filename)
        end = time.perf_counter()
        elapsed = end-start
        print(f"[TIMER] knapsack {self.knapsackSolver} took {elapsed:.6f} seconds")
        return selected_items, selected_weight, max_value

    def saveCSV(self, dp: list, items: list, capacity: int, filename: str):
        with open(filename+".csv", 'w', newline='') as f:
            writer = csv.writer(f)

            # Header: capacities from 0 to capacity
            header = [''] + [str(j) for j in range(capacity + 1)]
            writer.writerow(header)

            # First row: dp[0], meaning "no items considered"
            first_row = [''] + [(val if val is not None else '#') for val in dp[0]]
            writer.writerow(first_row)

            # Following rows: each item
            for i in range(1, len(dp)):
                row_label = f"({items[i - 1][1]}, {items[i - 1][2]})"
                row = [row_label] + [(val if val is not None else '#') for val in dp[i]]
                writer.writerow(row)

